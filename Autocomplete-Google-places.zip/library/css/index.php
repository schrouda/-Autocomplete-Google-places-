<?php
// Silence is golden
