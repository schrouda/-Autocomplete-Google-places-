<?php
# Silence is golden.